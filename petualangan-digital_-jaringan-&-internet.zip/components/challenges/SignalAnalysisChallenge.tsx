import React, { useState, useMemo } from 'react';

interface SignalAnalysisChallengeProps {
  onComplete: () => void;
}

const SignalAnalysisChallenge: React.FC<SignalAnalysisChallengeProps> = ({ onComplete }) => {
  const [distance, setDistance] = useState(5); // km
  const [obstruction, setObstruction] = useState<'none' | 'trees' | 'building'>('none');
  const [weather, setWeather] = useState<'clear' | 'rainy' | 'stormy'>('clear');
  const [analysisDone, setAnalysisDone] = useState(false);

  const signalStrength = useMemo(() => {
    let strength = 100; // Max signal

    // Distance penalty
    strength -= distance * 3; // 3 points per km

    // Obstruction penalty
    if (obstruction === 'trees') strength -= 15;
    if (obstruction === 'building') strength -= 30;

    // Weather penalty
    if (weather === 'rainy') strength -= 10;
    if (weather === 'stormy') strength -= 25;
    
    return Math.max(0, Math.min(100, Math.round(strength))); // Clamp between 0 and 100
  }, [distance, obstruction, weather]);

  const getSignalBarColor = () => {
    if (signalStrength > 70) return 'bg-green-500';
    if (signalStrength > 40) return 'bg-yellow-500';
    return 'bg-red-500';
  };
  
  const handleCompleteAnalysis = () => {
    setAnalysisDone(true);
    setTimeout(onComplete, 1500);
  }

  return (
    <div className="p-4 border border-sky-500 rounded-lg bg-slate-700/50 text-slate-200">
      <h3 className="text-lg font-semibold mb-3 text-sky-300">Tantangan: Detektif Sinyal</h3>
      <p className="mb-4 text-sm">Amati bagaimana faktor-faktor berikut mempengaruhi kekuatan sinyal seluler. Sesuaikan nilainya dan perhatikan perubahannya.</p>

      <div className="space-y-4 mb-6">
        {/* Distance */}
        <div>
          <label htmlFor="distance" className="block text-sm font-medium mb-1">Jarak dari BTS: {distance} km</label>
          <input
            type="range"
            id="distance"
            min="1"
            max="30"
            value={distance}
            onChange={(e) => setDistance(Number(e.target.value))}
            className="w-full h-2 bg-slate-600 rounded-lg appearance-none cursor-pointer accent-sky-500"
          />
        </div>

        {/* Obstruction */}
        <div>
          <label htmlFor="obstruction" className="block text-sm font-medium mb-1">Halangan Material:</label>
          <select
            id="obstruction"
            value={obstruction}
            onChange={(e) => setObstruction(e.target.value as typeof obstruction)}
            className="w-full p-2 bg-slate-600 border border-slate-500 rounded-md focus:ring-sky-500 focus:border-sky-500"
          >
            <option value="none">Tidak Ada</option>
            <option value="trees">Pepohonan</option>
            <option value="building">Bangunan Tembok</option>
          </select>
        </div>

        {/* Weather */}
        <div>
          <label htmlFor="weather" className="block text-sm font-medium mb-1">Cuaca:</label>
          <select
            id="weather"
            value={weather}
            onChange={(e) => setWeather(e.target.value as typeof weather)}
            className="w-full p-2 bg-slate-600 border border-slate-500 rounded-md focus:ring-sky-500 focus:border-sky-500"
          >
            <option value="clear">Cerah</option>
            <option value="rainy">Hujan Ringan</option>
            <option value="stormy">Badai</option>
          </select>
        </div>
      </div>

      <div className="my-4">
        <p className="text-sm font-medium mb-1">Perkiraan Kekuatan Sinyal:</p>
        <div className="w-full bg-slate-600 rounded-full h-6 overflow-hidden">
          <div
            className={`h-full rounded-full transition-all duration-300 ease-linear ${getSignalBarColor()}`}
            style={{ width: `${signalStrength}%` }}
          >
            <span className="flex items-center justify-center h-full text-xs font-medium text-white">
              {signalStrength}%
            </span>
          </div>
        </div>
      </div>
      
      {!analysisDone ? (
        <button 
          onClick={handleCompleteAnalysis}
          className="mt-6 w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded"
        >
          Selesai Analisis
        </button>
      ) : (
        <p className="mt-6 text-center text-green-400 font-semibold animate-pulse">
          Analisis selesai! Kamu telah memahami faktor-faktor sinyal.
        </p>
      )}
    </div>
  );
};

export default SignalAnalysisChallenge;