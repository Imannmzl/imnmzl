import React, { useState, useEffect } from 'react';

interface LanSetupChallengeProps {
  onComplete: () => void;
}

const LanSetupChallenge: React.FC<LanSetupChallengeProps> = ({ onComplete }) => {
  const [pcToSwitchConnected, setPcToSwitchConnected] = useState(false);
  const [switchToRouterConnected, setSwitchToRouterConnected] = useState(false);
  const [showFeedback, setShowFeedback] = useState(false);

  useEffect(() => {
    if (pcToSwitchConnected && switchToRouterConnected) {
      setShowFeedback(true);
      const timer = setTimeout(() => {
        onComplete();
      }, 1500); // Delay before completing to show feedback
      return () => clearTimeout(timer);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pcToSwitchConnected, switchToRouterConnected]);

  const connectPcToSwitch = () => {
    setPcToSwitchConnected(true);
  };

  const connectSwitchToRouter = () => {
    setSwitchToRouterConnected(true);
  };

  return (
    <div className="p-4 border border-sky-500 rounded-lg bg-slate-700/50 text-slate-200">
      <h3 className="text-lg font-semibold mb-3 text-sky-300">Tantangan: Rakit Jaringan LAN</h3>
      <p className="mb-4 text-sm">Hubungkan perangkat berikut secara berurutan untuk membangun jaringan lokal:</p>
      
      <div className="space-y-3">
        {/* PC */}
        <div className={`p-3 rounded-md flex items-center justify-between ${pcToSwitchConnected ? 'bg-green-600' : 'bg-slate-600'}`}>
          <span className="font-medium">Komputer (PC)</span>
          {!pcToSwitchConnected && (
            <button 
              onClick={connectPcToSwitch}
              className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm"
            >
              Hubungkan ke Switch
            </button>
          )}
          {pcToSwitchConnected && <span className="text-sm text-green-200">Terhubung ke Switch!</span>}
        </div>

        {/* Switch */}
        <div className={`p-3 rounded-md flex items-center justify-between ${switchToRouterConnected ? 'bg-green-600' : (pcToSwitchConnected ? 'bg-slate-600' : 'bg-slate-800 opacity-50')}`}>
          <span className="font-medium">Switch</span>
          {pcToSwitchConnected && !switchToRouterConnected && (
            <button 
              onClick={connectSwitchToRouter}
              className="bg-blue-500 hover:bg-blue-600 text-white px-3 py-1 rounded text-sm"
            >
              Hubungkan ke Router
            </button>
          )}
          {switchToRouterConnected && <span className="text-sm text-green-200">Terhubung ke Router!</span>}
          {!pcToSwitchConnected && <span className="text-xs text-slate-400">(Hubungkan PC dulu)</span>}
        </div>
        
        {/* Router */}
         <div className={`p-3 rounded-md ${switchToRouterConnected ? 'bg-slate-600' : 'bg-slate-800 opacity-50'}`}>
          <span className="font-medium">Router</span>
           {!switchToRouterConnected && <span className="text-xs text-slate-400 ml-2">(Menunggu koneksi dari Switch)</span>}
        </div>
      </div>

      {showFeedback && (
        <p className="mt-4 text-center text-green-400 font-semibold animate-pulse">
          Jaringan berhasil dirakit! Semua perangkat terhubung dengan benar.
        </p>
      )}
    </div>
  );
};

export default LanSetupChallenge;