import React, { useState, useEffect } from 'react';

interface DataTransmissionSimChallengeProps {
  onComplete: () => void;
}

const DataTransmissionSimChallenge: React.FC<DataTransmissionSimChallengeProps> = ({ onComplete }) => {
  const originalMessage = "RAHASIA";
  const [displayedMessage, setDisplayedMessage] = useState(originalMessage);
  const [step, setStep] = useState<'initial' | 'encrypting' | 'encrypted' | 'sending' | 'sent'>('initial');
  const [packets, setPackets] = useState<string[]>([]);

  const encryptMessage = () => {
    setStep('encrypting');
    // Simple "encryption": shift char codes (not real encryption)
    let encrypted = "";
    for (let i = 0; i < originalMessage.length; i++) {
      encrypted += String.fromCharCode(originalMessage.charCodeAt(i) + 3);
    }
    setTimeout(() => {
      setDisplayedMessage(encrypted);
      setStep('encrypted');
    }, 1000);
  };

  const sendMessage = () => {
    setStep('sending');
    // Split into "packets"
    const numPackets = 3;
    const chunkSize = Math.ceil(displayedMessage.length / numPackets);
    const newPackets = [];
    for (let i = 0; i < displayedMessage.length; i += chunkSize) {
        newPackets.push(displayedMessage.substring(i, i + chunkSize));
    }
    setPackets(newPackets);

    setTimeout(() => {
      setStep('sent');
    }, 1500 + newPackets.length * 500); // Animation delay
  };
  
  useEffect(() => {
    if (step === 'sent') {
        const timer = setTimeout(onComplete, 1500);
        return () => clearTimeout(timer);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [step]);


  return (
    <div className="p-4 border border-sky-500 rounded-lg bg-slate-700/50 text-slate-200">
      <h3 className="text-lg font-semibold mb-3 text-sky-300">Tantangan: Enkripsi & Kirim!</h3>
      <p className="mb-4 text-sm">Amati proses enkripsi dan pengiriman pesan rahasia.</p>

      <div className="mb-4 p-3 bg-slate-800 rounded min-h-[60px]">
        <p className="text-xs mb-1">Pesan Saat Ini:</p>
        <p className={`font-mono text-lg ${step === 'encrypting' ? 'animate-pulse text-yellow-400' : (step === 'encrypted' || step === 'sending' ? 'text-lime-400' : 'text-slate-100')}`}>
          {displayedMessage}
        </p>
      </div>

      {step === 'initial' && (
        <button onClick={encryptMessage} className="w-full bg-yellow-500 hover:bg-yellow-600 text-slate-900 font-semibold py-2 px-4 rounded">
          Enkripsi Pesan
        </button>
      )}

      {step === 'encrypting' && (
        <p className="text-center text-yellow-400 animate-pulse">Mengenkripsi pesan...</p>
      )}

      {step === 'encrypted' && (
        <button onClick={sendMessage} className="w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded">
          Kirim Pesan Terenkripsi
        </button>
      )}

      {step === 'sending' && (
        <div className="mt-4">
          <p className="text-center text-sky-400 mb-2 animate-pulse">Mengirim paket data...</p>
          <div className="flex flex-col items-center space-y-1">
            {packets.map((packet, index) => (
              <div 
                key={index} 
                className="bg-purple-600 text-white px-2 py-1 rounded text-xs animate-slide-down"
                style={{animationDelay: `${index * 0.5}s`}}
              >
                Paket {index + 1}: [{packet}] ➔ BTS ➔ Jaringan Inti
              </div>
            ))}
          </div>
           {/* Basic CSS for animation */}
          <style>{`
            @keyframes slide-down {
              0% { opacity: 0; transform: translateY(-20px); }
              100% { opacity: 1; transform: translateY(0); }
            }
            .animate-slide-down { animation: slide-down 0.5s ease-out forwards; }
          `}</style>
        </div>
      )}
      
      {step === 'sent' && (
        <p className="mt-4 text-center text-green-400 font-semibold animate-pulse">
          Pesan rahasia berhasil dikirim dengan aman!
        </p>
      )}
    </div>
  );
};

export default DataTransmissionSimChallenge;