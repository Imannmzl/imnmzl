import React, { useState } from 'react';

interface PhishingDetectionChallengeProps {
  onComplete: () => void;
}

interface EmailExample {
  id: string;
  subject: string;
  sender: string;
  snippet: string;
  isPhishing: boolean;
}

const EMAILS: EmailExample[] = [
  { id: 'email1', subject: 'Peringatan Keamanan Akun Anda!', sender: 'secure-mybank.com@support.info', snippet: 'Kami mendeteksi login mencurigakan. Klik disini untuk verifikasi segera: http://mybank-securelogin.xyz/validate', isPhishing: true },
  { id: 'email2', subject: 'Newsletter Mingguan Teknologi Terbaru', sender: 'newsletter@techupdates.co.id', snippet: 'Baca rangkuman berita teknologi minggu ini. Prosesor baru, update OS, dan lainnya!', isPhishing: false },
  { id: 'email3', subject: 'Selamat! Anda Memenangkan iPhone Gratis!', sender: 'promo.giveaway@luckywinner.net', snippet: 'Anda terpilih sebagai pemenang iPhone 15 Pro! Klaim hadiah Anda sekarang juga: www.get-free-iphone-now.biz/claim', isPhishing: true },
  { id: 'email4', subject: 'Konfirmasi Pesanan #12345', sender: 'cs@tokoonlinefavorit.com', snippet: 'Pesanan Anda untuk "Buku Jaringan Komputer" telah kami terima dan sedang diproses. Terima kasih!', isPhishing: false },
];


const PhishingDetectionChallenge: React.FC<PhishingDetectionChallengeProps> = ({ onComplete }) => {
  const [markedAsPhishing, setMarkedAsPhishing] = useState<Set<string>>(new Set());
  const [submitted, setSubmitted] = useState(false);
  const [score, setScore] = useState(0);

  const toggleMarkPhishing = (emailId: string) => {
    if (submitted) return;
    const newSet = new Set(markedAsPhishing);
    if (newSet.has(emailId)) {
      newSet.delete(emailId);
    } else {
      newSet.add(emailId);
    }
    setMarkedAsPhishing(newSet);
  };

  const handleSubmit = () => {
    setSubmitted(true);
    let correctIdentifications = 0;
    EMAILS.forEach(email => {
      if (email.isPhishing && markedAsPhishing.has(email.id)) {
        correctIdentifications++;
      }
      if (!email.isPhishing && !markedAsPhishing.has(email.id)) {
        correctIdentifications++; // Correctly identified as not phishing
      }
    });
    setScore(correctIdentifications);
    // For simplicity, complete if at least half are correct, or all phishing emails are found.
    const actualPhishingEmails = EMAILS.filter(e => e.isPhishing).length;
    const correctlyMarkedPhishing = EMAILS.filter(e => e.isPhishing && markedAsPhishing.has(e.id)).length;

    if (correctlyMarkedPhishing >= actualPhishingEmails -1 && correctIdentifications >= EMAILS.length -1) { // Allow one mistake overall for now
         setTimeout(onComplete, 2500);
    }
  };

  return (
    <div className="p-4 border border-sky-500 rounded-lg bg-slate-700/50 text-slate-200">
      <h3 className="text-lg font-semibold mb-3 text-sky-300">Tantangan: Berburu Phisher!</h3>
      <p className="mb-4 text-sm">Analisis contoh email berikut. Tandai mana yang menurutmu adalah upaya phishing.</p>

      <div className="space-y-3">
        {EMAILS.map(email => (
          <div key={email.id} className={`p-3 rounded-md border-2 ${markedAsPhishing.has(email.id) ? 'border-red-500 bg-red-900/30' : 'border-slate-600 bg-slate-800'}`}>
            <p className="text-xs text-slate-400">Dari: {email.sender}</p>
            <p className="font-semibold text-sky-400">{email.subject}</p>
            <p className="text-xs mt-1 text-slate-300">{email.snippet}</p>
            {!submitted && (
              <button
                onClick={() => toggleMarkPhishing(email.id)}
                className={`mt-2 text-xs px-3 py-1 rounded ${markedAsPhishing.has(email.id) ? 'bg-red-500 hover:bg-red-600 text-white' : 'bg-slate-600 hover:bg-slate-500 text-slate-200'}`}
              >
                {markedAsPhishing.has(email.id) ? 'Batalkan Tanda Phishing' : 'Tandai sebagai Phishing'}
              </button>
            )}
            {submitted && (
              <p className={`mt-1 text-xs font-bold ${email.isPhishing ? 'text-red-400' : 'text-green-400'}`}>
                {email.isPhishing ? '(Ini adalah Phishing)' : '(Ini Email Aman)'}
              </p>
            )}
          </div>
        ))}
      </div>

      {!submitted && (
        <button onClick={handleSubmit} className="mt-6 w-full bg-green-500 hover:bg-green-600 text-white font-semibold py-2 px-4 rounded">
          Periksa Jawaban Saya
        </button>
      )}

      {submitted && (
        <div className="mt-4 text-center">
          <p className="font-semibold text-lg">Hasil Identifikasi:</p>
          <p>Kamu mengidentifikasi dengan benar {score} dari {EMAILS.length} skenario.</p>
          { (score >= EMAILS.length - 1) ? (
            <p className="text-green-400 mt-1">Kerja bagus! Kamu berhasil mengidentifikasi sebagian besar ancaman phishing.</p>
          ) : (
            <p className="text-yellow-400 mt-1">Tidak buruk, tapi masih ada yang terlewat. Perhatikan baik-baik ciri-ciri email phishing!</p>
          )}
           {! (score >= EMAILS.length - 1) && (
             <button onClick={() => {setSubmitted(false); setMarkedAsPhishing(new Set()); setScore(0);}} className="mt-2 bg-amber-500 hover:bg-amber-600 text-white text-sm py-1 px-3 rounded">
                Coba Lagi
            </button>
           )

           }
        </div>
      )}
    </div>
  );
};

export default PhishingDetectionChallenge;