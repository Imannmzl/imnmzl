import React, { useState, useEffect } from 'react';

interface BrowserSecuritySetupChallengeProps {
  onComplete: () => void;
}

interface SecuritySetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
}

const INITIAL_SETTINGS: SecuritySetting[] = [
  { id: 'httpsE', label: 'Selalu Gunakan HTTPS (HTTPS Everywhere)', description: 'Memastikan koneksi terenkripsi ke situs web jika tersedia.', enabled: false },
  { id: 'blockPopups', label: 'Blokir Pop-up', description: 'Mencegah jendela pop-up yang mengganggu dan berpotensi berbahaya.', enabled: false },
  { id: 'blockTrackers', label: 'Blokir Pelacak Pihak Ketiga', description: 'Menghentikan situs web lain melacak aktivitas browsing Anda di berbagai situs.', enabled: false },
  { id: 'updateBrowser', label: 'Perbarui Browser Otomatis', description: 'Memastikan browser selalu mendapatkan patch keamanan terbaru.', enabled: false },
];

const BrowserSecuritySetupChallenge: React.FC<BrowserSecuritySetupChallengeProps> = ({ onComplete }) => {
  const [settings, setSettings] = useState<SecuritySetting[]>(INITIAL_SETTINGS);
  const [allSecure, setAllSecure] = useState(false);

  const toggleSetting = (id: string) => {
    setSettings(prevSettings =>
      prevSettings.map(setting =>
        setting.id === id ? { ...setting, enabled: !setting.enabled } : setting
      )
    );
  };

  useEffect(() => {
    const isAllSecure = settings.every(setting => setting.enabled);
    if (isAllSecure) {
      setAllSecure(true);
      const timer = setTimeout(onComplete, 1500);
      return () => clearTimeout(timer);
    } else {
      setAllSecure(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [settings]);

  return (
    <div className="p-4 border border-sky-500 rounded-lg bg-slate-700/50 text-slate-200">
      <h3 className="text-lg font-semibold mb-3 text-sky-300">Tantangan: Kunci Browser!</h3>
      <p className="mb-4 text-sm">Aktifkan semua pengaturan keamanan berikut pada browser virtual ini untuk meningkatkan perlindungan online Anda.</p>

      <div className="space-y-4">
        {settings.map(setting => (
          <div key={setting.id} className={`p-3 rounded-md transition-colors duration-200 ${setting.enabled ? 'bg-green-700/30 border-l-4 border-green-500' : 'bg-slate-800'}`}>
            <div className="flex items-center justify-between">
              <label htmlFor={setting.id} className="font-medium text-slate-100 cursor-pointer">
                {setting.label}
              </label>
              <button
                id={setting.id}
                onClick={() => toggleSetting(setting.id)}
                className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${setting.enabled ? 'bg-green-500' : 'bg-slate-600'}`}
                aria-checked={setting.enabled}
                role="switch"
              >
                <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${setting.enabled ? 'translate-x-6' : 'translate-x-1'}`} />
              </button>
            </div>
            <p className="text-xs text-slate-400 mt-1">{setting.description}</p>
          </div>
        ))}
      </div>

      {allSecure && (
        <p className="mt-6 text-center text-green-400 font-semibold animate-pulse">
          Pengaturan keamanan browser berhasil dioptimalkan!
        </p>
      )}
       {!allSecure && (
        <p className="mt-6 text-center text-yellow-400 text-sm">
          Aktifkan semua pengaturan untuk melanjutkan.
        </p>
      )}
    </div>
  );
};

export default BrowserSecuritySetupChallenge;