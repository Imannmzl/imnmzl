import React, { useState } from 'react';

interface RoutingSimChallengeProps {
  onComplete: () => void;
}

type NodeId = 'START' | 'R1' | 'R2' | 'R3' | 'END_WRONG' | 'END_CORRECT';

interface BaseNode {
    id: NodeId;
    name: string;
}

interface PathNode extends BaseNode {
    type: 'PATH';
    next: NodeId[];
}

interface EndNode extends BaseNode {
    type: 'END';
    isCorrect: boolean;
}

type Node = PathNode | EndNode;

const NODES: Record<NodeId, Node> = {
  START: { id: 'START', name: 'PC Pengirim', type: 'PATH', next: ['R1'] },
  R1: { id: 'R1', name: 'Router A', type: 'PATH', next: ['R2', 'R3'] },
  R2: { id: 'R2', name: 'Router B (Salah)', type: 'PATH', next: ['END_WRONG'] },
  R3: { id: 'R3', name: 'Router C (Benar)', type: 'PATH', next: ['END_CORRECT'] },
  END_WRONG: { id: 'END_WRONG', name: 'Server Tujuan Salah', type: 'END', isCorrect: false },
  END_CORRECT: { id: 'END_CORRECT', name: 'Server Tujuan Benar', type: 'END', isCorrect: true },
};


const RoutingSimChallenge: React.FC<RoutingSimChallengeProps> = ({ onComplete }) => {
  const [selectedPath, setSelectedPath] = useState<NodeId[]>(['START']);
  const [feedback, setFeedback] = useState<string | null>(null);
  const [packetSent, setPacketSent] = useState(false);

  const currentNodeId = selectedPath[selectedPath.length - 1];
  const currentNode = NODES[currentNodeId];

  const handleNodeSelect = (nodeId: NodeId) => {
    if (packetSent || !currentNode || currentNode.type === 'END') return;

    if (currentNode.type === 'PATH' && currentNode.next?.includes(nodeId)) {
      setSelectedPath([...selectedPath, nodeId]);
      setFeedback(null);
      
      const nextNodeDetails = NODES[nodeId];
      if (nextNodeDetails.type === 'END') {
        setPacketSent(true);
        if (nextNodeDetails.isCorrect) {
          setFeedback('Paket data berhasil dikirim ke server tujuan yang benar!');
          setTimeout(onComplete, 2000);
        } else {
          setFeedback('Paket data sampai di server yang salah. Coba lagi dari awal.');
          setTimeout(() => {
            setSelectedPath(['START']);
            setPacketSent(false);
            setFeedback(null);
          }, 2500);
        }
      }
    } else {
      setFeedback('Koneksi tidak valid. Pilih router berikutnya dari jalur yang tersedia.');
    }
  };

  const resetPath = () => {
    setSelectedPath(['START']);
    setFeedback(null);
    setPacketSent(false);
  }

  return (
    <div className="p-4 border border-sky-500 rounded-lg bg-slate-700/50 text-slate-200">
      <h3 className="text-lg font-semibold mb-3 text-sky-300">Tantangan: Labirin Data</h3>
      <p className="mb-2 text-sm">Pilih jalur router yang benar untuk mengirim paket data dari PC Pengirim ke Server Tujuan Benar.</p>
      
      <div className="my-4 p-3 bg-slate-800 rounded">
        <p className="text-xs mb-1">Jalur Terpilih:</p>
        <div className="flex flex-wrap gap-2">
          {selectedPath.map((nodeId, index) => {
            const node = NODES[nodeId];
            let bgColor = 'bg-sky-600';
            if (node.type === 'END') {
              bgColor = node.isCorrect ? 'bg-green-500' : 'bg-red-500';
            }
            return (
              <span key={index} className={`px-2 py-1 rounded text-xs ${bgColor}`}>
                {node.name} {index < selectedPath.length -1 ? '➔' : ''}
              </span>
            );
          })}
        </div>
      </div>

      {!packetSent && currentNode && currentNode.type === 'PATH' && (
        <div className="mt-4">
          <p className="mb-2 font-medium">Pilih Router Berikutnya dari {currentNode.name}:</p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {currentNode.next?.map((nextNodeId) => (
              <button
                key={nextNodeId}
                onClick={() => handleNodeSelect(nextNodeId as NodeId)}
                className="w-full bg-blue-500 hover:bg-blue-600 text-white p-3 rounded transition-colors"
              >
                {NODES[nextNodeId as NodeId].name}
              </button>
            ))}
          </div>
        </div>
      )}

      {feedback && (
        <p className={`mt-4 text-center font-semibold ${feedback.includes('berhasil') ? 'text-green-400' : 'text-red-400'}`}>
          {feedback}
        </p>
      )}

      {(packetSent && currentNode.type === 'END' && !currentNode.isCorrect) || // If packet sent and ended on wrong node
       (currentNode.type === 'END' && !currentNode.isCorrect && !packetSent) // Or if stuck on wrong end node without sending (e.g. if logic allowed this)
      ? (
         <button onClick={resetPath} className="mt-4 w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold py-2 px-4 rounded">
            Coba Lagi
        </button>
      ) : null}
       {packetSent && currentNode.type === 'END' && !currentNode.isCorrect && (
         <button onClick={resetPath} className="mt-4 w-full bg-amber-500 hover:bg-amber-600 text-white font-semibold py-2 px-4 rounded">
            Coba Lagi
        </button>
      )}
    </div>
  );
};

export default RoutingSimChallenge;