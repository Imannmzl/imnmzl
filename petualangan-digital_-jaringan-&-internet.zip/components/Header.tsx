
import React from 'react';
import { Player } from '../types';
import { ALL_BADGES, QUESTS } from '../constants'; // Assuming QUESTS contains icon info for badges

// Simple Badge Icon placeholder
const BadgeIcon: React.FC<{ badgeName: string; earned: boolean; questIcon?: React.ReactNode }> = ({ badgeName, earned, questIcon }) => {
  const badgeStyle = earned ? 'bg-yellow-500 text-yellow-900' : 'bg-slate-700 text-slate-400';
  const IconComponent = questIcon || <StarIcon className="w-4 h-4" />;
  
  return (
    <div className={`p-1.5 rounded-md ${badgeStyle} flex items-center space-x-1 text-xs`} title={badgeName}>
      {React.cloneElement(IconComponent as React.ReactElement<React.SVGProps<SVGSVGElement>>, { className: `w-4 h-4 ${earned ? 'text-yellow-800' : 'text-slate-500'}` })}
      {/* <span className="hidden sm:inline">{badgeName}</span> */}
    </div>
  );
};

// Placeholder Star Icon for general badges if specific quest icon not found
const StarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" {...props}>
    <path fillRule="evenodd" d="M10.868 2.884c.321-.772 1.415-.772 1.736 0l1.83 4.426c.12.291.411.488.726.51l4.828.702c.828.121 1.16.977.543 1.563l-3.494 3.405c-.24.234-.35.588-.298.928l.824 4.808c.142.824-.722 1.464-1.47.998L10.26 18.05c-.274-.144-.61-.144-.884 0l-4.3 2.26c-.748.466-1.612-.174-1.47-.998l.824-4.808c.052-.34-.058-.694-.298-.928L.47 10.085c-.617-.586-.285-1.442.543-1.563l4.828-.702c.315-.022.606-.219.726-.51l1.83-4.426Z" clipRule="evenodd" />
  </svg>
);


interface HeaderProps {
  player: Player;
}

const Header: React.FC<HeaderProps> = ({ player }) => {
  const getQuestIconForBadge = (badgeName: string): React.ReactNode | undefined => {
    if (badgeName === "Master of Networks") return <StarIcon className="w-4 h-4" />;
    const quest = QUESTS.find(q => q.badgeName === badgeName);
    return quest?.icon;
  };
  
  return (
    <header className="bg-slate-800 p-4 shadow-lg sticky top-0 z-50">
      <div className="container mx-auto flex justify-between items-center">
        <h1 className="text-xl sm:text-2xl font-bold text-sky-400">Petualangan Digital</h1>
        <div className="flex items-center space-x-2 sm:space-x-4">
          <div className="text-sm sm:text-base">
            <span className="font-semibold text-amber-400">Poin:</span> {player.points}
          </div>
          <div className="flex space-x-1 sm:space-x-2">
            {ALL_BADGES.map(badgeName => (
              <BadgeIcon 
                key={badgeName} 
                badgeName={badgeName} 
                earned={player.badges.includes(badgeName)}
                questIcon={getQuestIconForBadge(badgeName)}
              />
            ))}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
