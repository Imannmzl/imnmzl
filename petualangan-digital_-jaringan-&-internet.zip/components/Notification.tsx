
import React, { useEffect, useState } from 'react';

interface NotificationProps {
  message: string | null;
  type: 'success' | 'error' | 'info';
  onDismiss: () => void;
}

const Notification: React.FC<NotificationProps> = ({ message, type, onDismiss }) => {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (message) {
      setVisible(true);
      const timer = setTimeout(() => {
        setVisible(false);
        onDismiss(); 
      }, 3000); // Auto-dismiss after 3 seconds
      return () => clearTimeout(timer);
    } else {
      setVisible(false);
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [message]); // Rerun when message changes

  if (!visible || !message) {
    return null;
  }

  let bgColor = 'bg-blue-500';
  if (type === 'success') bgColor = 'bg-green-500';
  if (type === 'error') bgColor = 'bg-red-500';

  return (
    <div 
      className={`fixed bottom-5 right-5 ${bgColor} text-white py-3 px-6 rounded-lg shadow-xl transition-opacity duration-300 ${visible ? 'opacity-100' : 'opacity-0'}`}
    >
      {message}
      <button onClick={() => { setVisible(false); onDismiss(); }} className="ml-4 font-bold text-lg">&times;</button>
    </div>
  );
};

export default Notification;
    