import React, { useState, useEffect } from 'react';
import { Quest, Stage, StageType, Item, NPC } from '../types';
import { NPCS } from '../constants';
import QuizModal from './QuizModal';

// Import new interactive challenge components
import LanSetupChallenge from './challenges/LanSetupChallenge';
import RoutingSimChallenge from './challenges/RoutingSimChallenge';
import SignalAnalysisChallenge from './challenges/SignalAnalysisChallenge';
import DataTransmissionSimChallenge from './challenges/DataTransmissionSimChallenge';
import PhishingDetectionChallenge from './challenges/PhishingDetectionChallenge';
import BrowserSecuritySetupChallenge from './challenges/BrowserSecuritySetupChallenge';

interface QuestViewProps {
  quest: Quest;
  currentStageIndex: number;
  onStageComplete: (pointsAwarded: number, itemCollected?: Item) => void;
  onQuizSubmit: (allCorrect: boolean, points: number) => void;
}

const QuestView: React.FC<QuestViewProps> = ({ quest, currentStageIndex, onStageComplete, onQuizSubmit }) => {
  const [showQuizModal, setShowQuizModal] = useState(false);
  const stage = quest.stages[currentStageIndex];

  useEffect(() => {
    if (stage?.type === StageType.QUIZ) {
      setShowQuizModal(true);
    } else {
      setShowQuizModal(false);
    }
  }, [stage]);

  if (!stage) {
    return <div className="p-8 text-center text-xl text-slate-300">Memuat stage berikutnya...</div>;
  }
  
  const npcDetails = stage.npcName ? Object.values(NPCS).find(npc => npc.name === stage.npcName) : undefined;

  const renderStageContent = () => {
    const handleChallengeInteractionComplete = () => {
      // Points are awarded by the stage definition
      onStageComplete(stage.pointsAwarded || 0);
    };

    switch (stage.type) {
      case StageType.INFO:
        return (
          <div className="space-y-3">
            {Array.isArray(stage.infoText) ? stage.infoText.map((text, i) => <p key={i} className="text-slate-300 leading-relaxed">{text}</p>) : <p className="text-slate-300 leading-relaxed">{stage.infoText}</p>}
          </div>
        );
      case StageType.DIALOGUE:
        return (
          <div className="flex items-start space-x-4">
            {npcDetails?.avatarUrl && <img src={npcDetails.avatarUrl} alt={npcDetails.name} className="w-16 h-16 rounded-full border-2 border-sky-400" />}
            <div className="bg-slate-700 p-4 rounded-lg flex-1">
              <h4 className="font-semibold text-sky-300 mb-1">{stage.npcName || 'Narator'}</h4>
              {Array.isArray(stage.dialogue) ? 
                stage.dialogue.map((line, i) => (
                  typeof line === 'string' ? <p key={i} className="text-slate-200 mb-1">{line}</p> : <p key={i} className="text-slate-200 mb-1"><strong>{line.speaker}:</strong> {line.text}</p>
                ))
                : <p className="text-slate-200">{stage.dialogue}</p>
              }
            </div>
          </div>
        );
      case StageType.CHALLENGE:
        return (
          <div>
            <p className="mb-3 text-slate-300 font-medium">{stage.challengeDescription}</p>
            {stage.challengeComponent === 'LAN_SETUP' && <LanSetupChallenge onComplete={handleChallengeInteractionComplete} />}
            {stage.challengeComponent === 'ROUTING_SIM' && <RoutingSimChallenge onComplete={handleChallengeInteractionComplete} />}
            {stage.challengeComponent === 'SIGNAL_ANALYSIS' && <SignalAnalysisChallenge onComplete={handleChallengeInteractionComplete} />}
            {stage.challengeComponent === 'DATA_TRANSMISSION_SIM' && <DataTransmissionSimChallenge onComplete={handleChallengeInteractionComplete} />}
            {stage.challengeComponent === 'PHISHING_DETECTION' && <PhishingDetectionChallenge onComplete={handleChallengeInteractionComplete} />}
            {stage.challengeComponent === 'BROWSER_SECURITY_SETUP' && <BrowserSecuritySetupChallenge onComplete={handleChallengeInteractionComplete} />}
            {!['LAN_SETUP', 'ROUTING_SIM', 'SIGNAL_ANALYSIS', 'DATA_TRANSMISSION_SIM', 'PHISHING_DETECTION', 'BROWSER_SECURITY_SETUP'].includes(stage.challengeComponent || '') && (
              <p className="text-yellow-400">Komponen tantangan '{stage.challengeComponent}' belum diimplementasikan secara interaktif.</p>
            )}
          </div>
        );
      case StageType.COLLECT_ITEM:
        return (
          <div className="text-center">
            <p className="text-slate-200 mb-2">{stage.infoText || `Kamu mendapatkan item: ${stage.itemToCollect?.name}`}</p>
            {stage.itemToCollect?.icon && <div className="flex justify-center my-3 text-5xl">{stage.itemToCollect.icon}</div>}
            <p className="text-lg font-semibold text-amber-400">{stage.itemToCollect?.name}</p>
            <p className="text-sm text-slate-400 mb-4">{stage.itemToCollect?.description}</p>
          </div>
        );
      case StageType.QUEST_COMPLETE:
         return (
          <div className="text-center p-6 bg-green-700/30 rounded-lg">
            <h3 className="text-3xl font-bold text-green-400 mb-3">{stage.title || 'Misi Selesai!'}</h3>
            <p className="text-slate-200 text-lg mb-2">{stage.infoText}</p>
            <p className="text-amber-400 font-semibold">Poin +{stage.pointsAwarded || 0}</p>
            <p className="text-yellow-400 font-semibold">Lencana "{quest.badgeName}" diperoleh!</p>
          </div>
        );
      case StageType.QUIZ:
        return <p className="text-slate-300">Menyiapkan kuis...</p>; 
      default:
        return <p className="text-slate-400">Tipe stage tidak diketahui.</p>;
    }
  };

  const handleNext = () => {
    // Challenges and Quizzes handle their own completion flow and call onStageComplete/onQuizSubmit
    // This button is for INFO, DIALOGUE, COLLECT_ITEM, QUEST_COMPLETE stages
    if (stage.type === StageType.COLLECT_ITEM && stage.itemToCollect) {
      onStageComplete(stage.pointsAwarded || 0, stage.itemToCollect);
    } else if (stage.type === StageType.QUEST_COMPLETE) {
        onStageComplete(stage.pointsAwarded || 0); 
    } else if (stage.type !== StageType.QUIZ && stage.type !== StageType.CHALLENGE) {
      onStageComplete(stage.pointsAwarded || 0);
    }
  };
  
  const quizActive = stage.type === StageType.QUIZ && showQuizModal;
  // Only show "Lanjutkan" button for stages that don't have their own internal progression (like challenges or quizzes)
  const showNextButton = !quizActive && stage.type !== StageType.CHALLENGE;


  return (
    <div 
      className="bg-slate-800/70 backdrop-blur-md p-6 sm:p-8 rounded-xl shadow-2xl w-full max-w-3xl mx-auto my-8 min-h-[400px] flex flex-col justify-between transition-all duration-500 ease-in-out"
      style={{backgroundImage: stage.backgroundImageUrl ? `linear-gradient(rgba(30, 41, 59, 0.85), rgba(30, 41, 59, 0.95)), url(${stage.backgroundImageUrl})` : '', backgroundSize: 'cover', backgroundPosition: 'center'}}
    >
      <div>
        <h2 className="text-2xl sm:text-3xl font-bold text-sky-400 mb-1">{stage.title || quest.title}</h2>
        <p className="text-sm text-slate-400 mb-6">Misi {quest.id.substring(1)} / Tahap {currentStageIndex + 1} dari {quest.stages.length}</p>
        <div className="prose prose-invert max-w-none prose-p:text-slate-300 prose-headings:text-sky-300">
          {renderStageContent()}
        </div>
      </div>

      {showNextButton && (
        <button
          onClick={handleNext}
          className="mt-8 w-full bg-sky-500 hover:bg-sky-600 text-white font-bold py-3 px-4 rounded-lg transition-colors duration-150 text-lg shadow-md hover:shadow-lg transform hover:scale-105"
        >
          {stage.type === StageType.QUEST_COMPLETE ? 'Lanjutkan ke Misi Berikutnya' : 'Lanjutkan'}
        </button>
      )}

      {quizActive && stage.quizQuestions && (
        <QuizModal
          questions={stage.quizQuestions}
          onSubmit={(allCorrect, points) => {
            onQuizSubmit(allCorrect, points);
            setShowQuizModal(false); 
            // Advance stage after quiz. Points are already added by onQuizSubmit.
            // The 0 here is for stage points, not quiz points.
            onStageComplete(0); 
          }}
          onClose={() => {
             setShowQuizModal(false);
             // If quiz is closed without submitting, player might be stuck.
             // A "Lanjutkan" button might appear if showNextButton logic allows,
             // or they need to re-trigger quiz by re-entering stage (not ideal UX).
             // For now, closing modal after quiz means it's done.
          }}
        />
      )}
    </div>
  );
};

export default QuestView;