
import React from 'react';
import { Item } from '../types';

interface InventoryDisplayProps {
  inventory: Item[];
}

const InventoryDisplay: React.FC<InventoryDisplayProps> = ({ inventory }) => {
  return (
    <aside className="w-full md:w-64 bg-slate-800 p-4 rounded-lg shadow-md max-h-96 overflow-y-auto custom-scroll">
      <h2 className="text-xl font-semibold mb-3 text-sky-400 border-b border-slate-700 pb-2">Inventaris</h2>
      {inventory.length === 0 ? (
        <p className="text-slate-400 text-sm">Inventaris kosong. Selesaikan tantangan untuk mendapatkan item!</p>
      ) : (
        <ul className="space-y-2">
          {inventory.map((item, index) => (
            <li key={index} className="flex items-center p-2 bg-slate-700 rounded hover:bg-slate-600 transition-colors duration-150 group">
              <span className="mr-3 text-lg">{item.icon || '📦'}</span>
              <div>
                <h3 className="font-medium text-slate-100 text-sm">{item.name}</h3>
                <p className="text-xs text-slate-400 group-hover:text-slate-300">{item.description}</p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </aside>
  );
};

export default InventoryDisplay;
    