
import React, { useState } from 'react';
import { QuizQuestion } from '../types';

interface QuizModalProps {
  questions: QuizQuestion[];
  onSubmit: (answersCorrect: boolean, pointsEarned: number) => void;
  onClose: () => void;
}

const QuizModal: React.FC<QuizModalProps> = ({ questions, onSubmit, onClose }) => {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: string }>({});
  const [showResults, setShowResults] = useState(false);
  const [feedback, setFeedback] = useState<{ [key: number]: string }>({});

  const currentQuestion = questions[currentQuestionIndex];

  const handleAnswerSelect = (option: string) => {
    setSelectedAnswers(prev => ({ ...prev, [currentQuestionIndex]: option }));
    if (option === currentQuestion.correctAnswer) {
      setFeedback(prev => ({ ...prev, [currentQuestionIndex]: 'Jawaban Benar! ' + currentQuestion.explanation }));
    } else {
      setFeedback(prev => ({ ...prev, [currentQuestionIndex]: 'Jawaban Salah. Penjelasan: ' + currentQuestion.explanation }));
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    } else {
      setShowResults(true);
      // Calculate score after all questions are answered or "Finish" is clicked
      let correctCount = 0;
      questions.forEach((q, index) => {
        if (selectedAnswers[index] === q.correctAnswer) {
          correctCount++;
        }
      });
      onSubmit(correctCount === questions.length, correctCount * 10); // 10 points per correct answer
    }
  };


  if (showResults) {
    let correctCount = 0;
    questions.forEach((q, index) => {
      if (selectedAnswers[index] === q.correctAnswer) {
        correctCount++;
      }
    });

    return (
      <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[100]">
        <div className="bg-slate-800 p-6 rounded-lg shadow-xl max-w-lg w-full text-slate-100">
          <h2 className="text-2xl font-bold mb-4 text-sky-400">Hasil Kuis</h2>
          <p className="mb-2">Kamu menjawab {correctCount} dari {questions.length} pertanyaan dengan benar.</p>
          <p className="mb-4">Total poin dari kuis ini: {correctCount * 10}</p>
          {questions.map((q, index) => (
            <div key={index} className={`mb-3 p-3 rounded ${selectedAnswers[index] === q.correctAnswer ? 'bg-green-700' : 'bg-red-700'}`}>
              <p className="font-semibold">{q.question}</p>
              <p className="text-sm">Jawabanmu: {selectedAnswers[index] || 'Tidak dijawab'}</p>
              <p className="text-sm">Jawaban Benar: {q.correctAnswer}</p>
              {selectedAnswers[index] !== q.correctAnswer && <p className="text-xs mt-1">Penjelasan: {q.explanation}</p>}
            </div>
          ))}
          <button
            onClick={onClose}
            className="mt-4 w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded transition-colors duration-150"
          >
            Lanjutkan Petualangan
          </button>
        </div>
      </div>
    );
  }
  
  if (!currentQuestion) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-[100]">
      <div className="bg-slate-800 p-6 rounded-lg shadow-xl max-w-xl w-full text-slate-100">
        <h2 className="text-2xl font-bold mb-2 text-sky-400">Kuis Interaktif!</h2>
        <p className="text-sm text-slate-400 mb-4">Pertanyaan {currentQuestionIndex + 1} dari {questions.length}</p>
        
        <div className="mb-6 p-4 bg-slate-700 rounded">
          <h3 className="text-lg font-semibold mb-3">{currentQuestion.question}</h3>
          <div className="space-y-2">
            {currentQuestion.options.map((option, index) => (
              <button
                key={index}
                onClick={() => handleAnswerSelect(option)}
                disabled={!!selectedAnswers[currentQuestionIndex]}
                className={`w-full text-left p-3 rounded transition-colors duration-150 
                  ${selectedAnswers[currentQuestionIndex] === option ? (option === currentQuestion.correctAnswer ? 'bg-green-500 hover:bg-green-600' : 'bg-red-500 hover:bg-red-600') : 'bg-slate-600 hover:bg-slate-500'}
                  ${!!selectedAnswers[currentQuestionIndex] && selectedAnswers[currentQuestionIndex] !== option ? 'opacity-60' : ''}
                  ${!!selectedAnswers[currentQuestionIndex] ? 'cursor-not-allowed' : 'cursor-pointer'}`}
              >
                {option}
              </button>
            ))}
          </div>
        </div>

        {feedback[currentQuestionIndex] && (
          <div className={`p-3 mb-4 rounded text-sm ${selectedAnswers[currentQuestionIndex] === currentQuestion.correctAnswer ? 'bg-green-700 text-green-100' : 'bg-red-700 text-red-100'}`}>
            {feedback[currentQuestionIndex]}
          </div>
        )}
        
        {selectedAnswers[currentQuestionIndex] && (
           <button
            onClick={handleNextQuestion}
            className="w-full bg-sky-500 hover:bg-sky-600 text-white font-semibold py-2 px-4 rounded transition-colors duration-150"
          >
            {currentQuestionIndex < questions.length - 1 ? 'Pertanyaan Berikutnya' : 'Lihat Hasil'}
          </button>
        )}
      </div>
    </div>
  );
};

export default QuizModal;
    